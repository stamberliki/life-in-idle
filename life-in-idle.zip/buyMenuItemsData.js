export function buyMenuItemsData(game,itemNumber,x,y){

	function getObject(name, desc,costMoney,gainMoney,gainExp,point,itemNumber){
		return {
				icon:game.add.image(x,y,'buyMenuIcons',itemNumber).setOrigin(0).setScale(2),
				desc: desc,
				name: name,
				costMoney: costMoney,
				gainMoney: gainMoney,
				gainExp: gainExp,
				timeMultiplier: point,
				iconItemNumber: itemNumber,
				isBrought: false,
				canBeBrought: false,
				isUsed: false,
				point: point,
				};
	}

	switch(itemNumber){
		case 0:
			return getObject('Wooden Bedside Table','Requires 4 wood planks',300,0,2,1,itemNumber);//BST
		case 1:
			return getObject('Regular Bedside Table','Upgraded version of\nthe wooden one',525,0,2,2,itemNumber);
		case 2:
			return getObject('Traditional Bedside Table','Victorian Era bedside table',750,0,2,3,itemNumber);
		case 3:
			return getObject('Steel Bedside Table','Rustproof',1050,0,3,4,itemNumber);
		case 4:
			return getObject('Round Bedside Table','This is clearly the \nviolation of the cube law',1350,0,3,5,itemNumber);
		case 5:
			return getObject('Open Bedside Table','Dont put your expensive\nthings here',1800,0,3,6,itemNumber);
		case 6:
			return getObject('Glass Bedside Table','Dont stand on it',2250,0,3,7,itemNumber);
		case 7:
			return getObject('Metal Bedside Table','Note of death not included',2815,0,3,8,itemNumber);
		case 8:
			return getObject('Modern Bedside Table','Just put black and \bwhite on it and boom,\bmodern design',3375,0,3,9,itemNumber);
		case 9:
			return getObject('Low-end Computer','CRT Monitor and a\n5kg casing',27,0,3,3,itemNumber);//cmp
		case 10:
			return getObject('Average Computer','You can run minecraft\nwith this',32,0,3,6,itemNumber);
		case 11:
			return getObject('High-end Computer','But will it run crysis?',200,0,3,9,itemNumber);
		case 12:
			return getObject('Wooden Crib','This suppose to\nbe expensive',0,0,3,1,itemNumber);//crb
		case 13:
			return getObject('Regular Crib','Upgraded version of\nthw wooden vrib',483,0,3,2,itemNumber);
		case 14:
			return getObject('Spring Crib','Boing!',540,0,3,3,itemNumber);
		case 15:
			return getObject('Foldable Crib','Dont put the baby when folding',756,0,3,4,itemNumber);
		case 16:
			return getObject('Round Crib','This is clearly the \nviolation of the cube law',972,0,3,5,itemNumber);
		case 17:
			return getObject('Cozy Crib','How cozy it is?',1296,0,3,6,itemNumber);
		case 18:
			return getObject('Net Crib','No, its not for the fish',1620,0,3,7,itemNumber);
		case 19:
			return getObject('Rocking Crib','Dont roll on it',2025,0,3,8,itemNumber);
		case 20:
			return getObject('Modern Crib','Just put black and \bwhite on it and boom,\bmodern design',2430,0,3,9,itemNumber);
		case 21:
			return getObject('Wooden Desk','Just a scrap wood\nput together',300,0,3,1,itemNumber);//dsk
		case 22:
			return getObject('Regular Desk','Improve version of\nthe wooden desk',525,0,3,2,itemNumber);
		case 23:
			return getObject('Traditional Desk','A duplicate of the\npresidental desk',750,0,3,3,itemNumber);
		case 24:
			return getObject('Office Desk','They stole this from someone\'s office',1050,0,3,4,itemNumber);
		case 25:
			return getObject('Round Desk','This is clearly the \nviolation of the cube law',1350,0,3,5,itemNumber);
		case 26:
			return getObject('Steel Desk','Rustproof',1800,0,3,6,itemNumber);
		case 27:
			return getObject('Glass Desk','Dont make it a gaming desk',2250,0,3,7,itemNumber);
		case 28:
			return getObject('Metal Desk','Comes with more drawers',2815,0,3,8,itemNumber);
		case 29:
			return getObject('Moden Desk','Just put black and \bwhite on it and boom,\bmodern design',3375,0,3,9,itemNumber);
		case 30:
			return getObject('Low-end Console','Its not what you thinking',250,0,3,3,itemNumber);//gts
		case 31:
			return getObject('Low-end Cellphone','7777\n33\n66\n3 66\n88\n333\n7777',250,0,3,3,itemNumber);
		case 32:
			return getObject('Average Console','I\'ve brick this since I was a kid,\nits my first official console,\nand it never fixed,\nand it lasted a month(?)\n \n-Dev',250,0,3,6,itemNumber);
		case 33:
			return getObject('Average Cellphone','The phone of tomorrow',250,0,3,6,itemNumber);
		case 34:
			return getObject('High-end Console','If only we have more\nportable consoles',250,0,3,9,itemNumber);
		case 35:
			return getObject('High-end Cellphone','All screen phone is a\ngood idea they said',250,0,3,9,itemNumber);
		case 36:
			return getObject('Regular Bed','Get the foam, frame later',1260,0,3,2,itemNumber);//MB
		case 37:
			return getObject('Cozy Regular Bed','Requires 3 wool\nand 3 wood planks',2310,0,3,3,itemNumber);
		case 38:
			return getObject('Regular Post Bed','Dont even think about it',3150,0,3,4,itemNumber);
		case 39:
			return getObject('Regular Storage Bed','Save drawer space,\n300 IQ right here',4620,0,3,5,itemNumber);
		case 40:
			return getObject('Regular Iron Frame Bed','This must be\nthe cheapest',5670,0,3,6,itemNumber);
		case 41:
			return getObject('Regular Brass Bed','I never see this kind of bed\n-Dev',7920,0,3,7,itemNumber);
		case 42:
			return getObject('Regular Ornament Bed','Feel like royalty',9450,0,3,8,itemNumber);
		case 43:
			return getObject('Regular Sleigh Bed','Reindeer not included',12375,0,3,9,itemNumber);
		case 44:
			return getObject('Regular Modern Bed','Just put black and \bwhite on it and boom,\bmodern design',14175,0,3,10,itemNumber);
		case 45:
			return getObject('Queen Size Bed','Get the foam, frame later',2436,0,3,3,itemNumber);//QSB
		case 46:
			return getObject('Cozy Queen Size Bed','Requires 3 wool\nand 3 wood planks',4263,0,3,4,itemNumber);
		case 47:
			return getObject('Queen Size Post Bed','Dont even think about it',6090,0,3,5,itemNumber);
		case 48:
			return getObject('Queen Size Storage Bed','Save drawer space,\n300 IQ right here',8526,0,3,6,itemNumber);
		case 49:
			return getObject('Queen Size Iron Frame Bed','This must be\nthe cheapest',10962,0,3,7,itemNumber);
		case 50:
			return getObject('Queen Size Brass Bed','I never see this kind of bed\n-Dev',14616,0,3,8,itemNumber);
		case 51:
			return getObject('Queen Size Ornament Bed','Feel like royalty',18270,0,3,9,itemNumber);
		case 52:
			return getObject('Queen Size Sleigh Bed','Reindeer not included',22840,0,3,10,itemNumber);
		case 53:
			return getObject('Queen Size Modern Bed','Just put black and \bwhite on it and boom,\bmodern design',27405,0,3,1,itemNumber);
		case 54:
			return getObject('Paper And Penicl','Pen is mightier than the sword\nExcept is a pencil',216,0,19,1,itemNumber);//ScSu
		case 55:
			return getObject('Drawing Materials','Appreciate kid\'s drawings',378,0,21,2,itemNumber);
		case 56:
			return getObject('Alphabet Book','A-B-C-D-E-F-G-H-I-J-K\nGJFGKCDTNOP!',540,0,24,3,itemNumber);
		case 57:
			return getObject('Dictionary','Checking on how to spell a four letter word,\nJous tu bi shur',756,0,26,4,itemNumber);
		case 58:
			return getObject('Encyclopedia','Book of facts,\nuntil it revised',972,0,29,5,itemNumber);
		case 59:
			return getObject('Basic Math','2+2 is 4',1296,0,32,6,itemNumber);
		case 60:
			return getObject('Grammar 101','Your need too check\nyoure grammar',1620,0,35,7,itemNumber);
		case 61:
			return getObject('Computer Literacy Book','People need this tbh',2025,0,39,8,itemNumber);
		case 62:
			return getObject('Digital Encyclopedia','The future is now',2430,0,42,9,itemNumber);
		case 63:
			return getObject('Small Bed','Get the foam, frame later',260,0,3,1,itemNumber);//sBed
		case 64:
			return getObject('Cozy Small Bed','Requires 3 wool\nand 3 wood planks',455,0,3,2,itemNumber);
		case 65:
			return getObject('Small Post Bed','Dont even think about it',670,0,3,3,itemNumber);
		case 66:
			return getObject('Small Storage Bed','Save drawer space,\n300 IQ right here',920,0,3,4,itemNumber);
		case 67:
			return getObject('Small Iron Frame Bed','This must be\nthe cheapest',1155,0,3,5,itemNumber);
		case 68:
			return getObject('Small Brass Bed','I never see this kind of bed\n-Dev',1500,0,3,6,itemNumber);
		case 69:
			return getObject('Small Ornament Bed','Feel like royalty',1900,0,3,7,itemNumber);
		case 70:
			return getObject('Small Sleigh Bed','Reindeer not included',2475,0,3,8,itemNumber);
		case 71:
			return getObject('Small Modern Bed','Just put black and \bwhite on it and boom,\bmodern design',2950,0,3,9,itemNumber);
		case 72:
			return getObject('Building Blocks','Play this with your kid,\nit will be a engineer someday',276,0,22,1,itemNumber);//toys
		case 73:
			return getObject('Jigsaw Puzzle','Do you wanna play a game?',483,0,24,2,itemNumber);
		case 74:
			return getObject('Teddy Bear','Fluffy',690,0,27,3,itemNumber);
		case 75:
			return getObject('Puzzle Block','If it fits, it sits',966,0,29,4,itemNumber);
		case 76:
			return getObject('Toy Train','CHOO! CHOO!',1242,0,32,5,itemNumber);
		case 77:
			return getObject('Small Toy Cars','It will last a day',1656,0,36,6,itemNumber);
		case 78:
			return getObject('Toy Truck','It will last 2 days',2070,0,39,7,itemNumber);
		case 79:
			return getObject('Remote Control Toy Car','Battery last a week',2590,0,43,8,itemNumber);
		case 80:
			return getObject('Toy Drone','Weapon not included',3105,0,47,9,itemNumber);
	}

}